from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)
model = joblib.load('model.pkl')

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    user_input = []
    if request.method == 'POST':
        try:
            user_input = [
                int(request.form.get('input1')),
                int(request.form.get('input2')),
                int(request.form.get('input3')),
                int(request.form.get('input4'))
            ]
            X = np.array(user_input).reshape(1, -1)
            pred = model.predict(X)[0]
            prediction = 'BIG' if pred == 1 else 'SMALL'
        except Exception as e:
            prediction = f"Error: {str(e)}"
    return render_template('index.html', prediction=prediction, inputs=user_input)
    
if __name__ == '__main__':
    app.run(debug=True)
