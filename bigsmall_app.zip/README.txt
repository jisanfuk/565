BIG/SMALL Prediction Website - Setup Instructions

1. Requirements:
   - Python 3.x installed
   - pip installed

2. Install required packages:
   Run this command in your terminal or command prompt:
   pip install flask scikit-learn joblib numpy

3. Run the app:
   python app.py

4. Open your browser and go to:
   http://127.0.0.1:5000/

5. Use the form to input 4 numbers, then click "Predict" to get BIG or SMALL result.

---

Note: You can customize the model by training with your own data and replacing model.pkl.
